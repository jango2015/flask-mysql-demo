#
class NoDefault(object):
    pass

__all__ = [ 'NoDefault', ]
